#include "ofApp.h"

//namespace fs = of::filesystem;
void ofApp::setup(){
}

void ofApp::update(){
}

void ofApp::draw(){	
	img.draw(0, 0);
}

void ofApp::keyPressed(int key){
}
